def average(array):
    return sum(set(array))/len(set(array))
